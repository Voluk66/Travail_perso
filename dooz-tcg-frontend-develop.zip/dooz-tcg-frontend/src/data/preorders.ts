export const preorders = [
    {
        name: "Playmat - Nouveaux Héros",
        price: "20,00€",
        image: "/product_1.png"
    },
    {
        name: "Deck Lorcana - La Belle & La Bête - FR",
        price: "20,00€",
        image: "/product_2.png"
    },
    {
        name: "Deck Lorcana - Iago & Jafar - FR",
        price: "20,00€",
        image: "/product_3.png"
    },
    {
        name: "Coffret Lilo & Stitch - FR",
        price: "30,00€",
        image: "/product_1.png"
    }
]