import Layout from "./components/layout/Layout.tsx";
import HomePage from "./page/HomePage.tsx";
import {BrowserRouter, Routes, Route} from "react-router-dom";
import ProductDetail from "./page/ProductDetails.tsx";


function App() {
    return (
        <BrowserRouter>
            <Layout>
                <Routes>
                    <Route path="/" element={<HomePage />} />
                    <Route path={"/products/:productId"} element={<ProductDetail />} />
                </Routes>
            </Layout>
        </BrowserRouter>

    )
}

export default App
